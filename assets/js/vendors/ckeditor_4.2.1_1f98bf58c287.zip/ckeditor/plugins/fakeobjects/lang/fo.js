﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'fo', {
	anchor: 'Anchor',
	flash: 'Flash Animation',
	hiddenfield: 'Fjaldur teigur',
	iframe: 'IFrame',
	unknown: 'Ókent Object'
});
