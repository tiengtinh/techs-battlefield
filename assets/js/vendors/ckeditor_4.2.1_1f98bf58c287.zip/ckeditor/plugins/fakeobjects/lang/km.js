﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'km', {
	anchor: 'បន្ថែម/កែប្រែ យុថ្កា',
	flash: 'Flash Animation', // MISSING
	hiddenfield: 'ជួរលាក់',
	iframe: 'IFrame', // MISSING
	unknown: 'Unknown Object' // MISSING
});
