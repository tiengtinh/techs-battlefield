﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'el', {
	toolbarCollapse: 'Σύμπτηξη Εργαλειοθήκης',
	toolbarExpand: 'Ανάπτυξη Εργαλειοθήκης',
	toolbarGroups: {
		document: 'Έγγραφο',
		clipboard: 'Clipboard/Undo',
		editing: 'Σε επεξεργασία',
		forms: 'Φόρμες',
		basicstyles: 'Βασικά στυλ',
		paragraph: 'Παράγραφος',
		links: 'Συνδέσμοι',
		insert: 'Εισαγωγή',
		styles: 'Στυλ',
		colors: 'Χρώματα',
		tools: 'Εργαλεία'
	},
	toolbars: 'Εργαλειοθήκες Επεξεργαστή'
});
