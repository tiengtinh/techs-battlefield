﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'toolbar', 'zh', {
	toolbarCollapse: '折叠工具栏',
	toolbarExpand: '展开工具栏',
	toolbarGroups: {
		document: 'Document',
		clipboard: 'Clipboard/Undo',
		editing: 'Editing',
		forms: 'Forms',
		basicstyles: 'Basic Styles',
		paragraph: 'Paragraph',
		links: 'Links',
		insert: 'Insert',
		styles: 'Styles',
		colors: 'Colors',
		tools: 'Tools'
	},
	toolbars: '編輯器工具欄'
});
